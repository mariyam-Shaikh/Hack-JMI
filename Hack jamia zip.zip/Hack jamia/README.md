# Hack-JMI
Hackathon project for Jamia Millia Islamia
